document.addEventListener("DOMContentloaded",function(){ 
    const formCadastro = document.getElementById("formCadastro");
    if (formCadastro){


    formCadastro,addEventListener("subimit", async (e)=> {
        const dados = Object.fromEntries
         new FormData (formCadastro)
         try{
            const resp = await fetch('/api/cadastrar',
                method
            )
         }catch(erro)


        console.log("Dados capturafos:");
        console.log("Nome:",dados.nome);
        console.log("Email:,dados.email");
        console.log("Telefone:", dados.telefone);
        console.log(dados);
    } );
    }    
});