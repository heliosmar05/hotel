
import os
from flask import Flask, send_from_directory
import openpyxl 
from datetime import ( 
      datetime,
)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

FRONTEND_DIR = os.path.join(BASE_DIR,"frontend")

STATIC_DIR = os.path.join(FRONTEND_DIR,"static")

DB_DIR = os.path.join(os.path.dirname(__file__), "..","DB")
EXCEL_FILE = os.path.join(DB_DIR,"clientes.xlsx")
COLUMNS =[
      "ID"
      "NOME"
      "CPF"
      "EMIL"
      "telefone não deixa o seu trabalho aberto, podem mecher"
      "endereço"
      "observações"
      "data cadastro"
]

def init_excel():
      if not os.patn.exists(DB_DIR):
            os.makedirs(DB_DIR)

      if not os.path.exists(EXCEL_FILE):
       workbook = openpyxl.workbook()
       sheet = workbook.active
       sheet.title = "Clientes"
       sheet.append(COLUMNS)
       workbook.save(EXCEL_FILE)


   
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path='/static')  # Fixed typo in static_url_path

@app.route("/")
def home():
         return send_from_directory(FRONTEND_DIR,"index.html")

@app.route("/consulta")
def consulta_page():
     return send_from_directory(FRONTEND_DIR,"consulta.html")

@app.route("/alterar")
def alterar_page():
      return send_from_directory(FRONTEND_DIR, "altera.html")

if __name__ == "__main__":  
    print("BASE_DIR:", BASE_DIR)
    print("FRONTEND_DIR:",FRONTEND_DIR)
    print("STATIC_DIR:",STATIC_DIR)
    app.run(debug=True)